jQuery(document).ready(function() {

    /*
        Fullscreen background
    */
    $.backstretch("../assets/demo/images/backgrounds/bg6.jpg");


});